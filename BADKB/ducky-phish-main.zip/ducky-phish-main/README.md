# ducky-phish
A rubber ducky script that does a simple phishing attack



# how to use:

if you want a walkthrough of how to use this script, you can see it in this yt video:
https://youtu.be/NeD5kRLatOU

or join my discord for support:
https://discord.com/invite/73fuArq
