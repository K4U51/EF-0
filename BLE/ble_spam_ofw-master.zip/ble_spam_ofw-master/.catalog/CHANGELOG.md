## v 2.0

- Backported to earlier firmware by searching memory for symbol, first release
