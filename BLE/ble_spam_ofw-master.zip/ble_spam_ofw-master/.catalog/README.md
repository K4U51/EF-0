# BLE Spam

This Flipper application ("FAP") spams broadcast packets to Apple, Android, and Windows devices, which may be up to 5 meters away.

## Usage

Select the desired attack using left and right, the interval using up and down, and press the Start button to begin broadcasting. Press the Stop button to end broadcasting.

## Credits

Original app by @WillyJL

Extensive testing and research on behavior and parameters by @WillyJL, @ECTO-1A, and @Spooks4576

Structures docs and Nearby Action IDs from https://github.com/furiousMAC/continuity/

Proximity Pair IDs from https://github.com/ECTO-1A/AppleJuice/

Airtag ID from https://techryptic.github.io/2023/09/01/Annoying-Apple-Fans/

Ported/backported by @noproto and @JulanDeAlb
