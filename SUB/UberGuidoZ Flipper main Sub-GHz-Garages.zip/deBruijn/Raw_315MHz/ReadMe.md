Sub-2Ghz raw captures of the deBruijn sequence for 8, 9, 10, 11 and 12 bits

These source of these files were generated using Universal Radio Hacker and transmitted using a HackeRF One SDR.

Credit: https://github.com/jimilinuxguy/flipperzero-deBruijn
