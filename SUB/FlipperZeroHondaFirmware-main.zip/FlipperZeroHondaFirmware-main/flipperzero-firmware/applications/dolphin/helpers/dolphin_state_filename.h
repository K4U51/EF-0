#pragma once

#define DOLPHIN_STATE_FILE_NAME ".dolphin.state"
