#pragma once
#include "dialogs_message.h"

#ifdef __cplusplus
extern "C" {
#endif

bool dialogs_app_process_module_file_browser(const DialogsAppMessageDataFileBrowser* data);

#ifdef __cplusplus
}
#endif
