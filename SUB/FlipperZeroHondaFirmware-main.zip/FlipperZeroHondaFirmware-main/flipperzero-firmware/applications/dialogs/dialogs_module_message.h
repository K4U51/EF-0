#pragma once
#include "dialogs_message.h"

#ifdef __cplusplus
extern "C" {
#endif

DialogMessageButton dialogs_app_process_module_message(const DialogsAppMessageDataDialog* data);

#ifdef __cplusplus
}
#endif
