/**
 * @file cli_vcp.h
 * VCP HAL API
 */

#pragma once

#include "cli_i.h"

#ifdef __cplusplus
extern "C" {
#endif

extern CliSession cli_vcp;

#ifdef __cplusplus
}
#endif
