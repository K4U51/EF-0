#pragma once

#define BT_KEYS_STORAGE_FILE_NAME ".bt.keys"
