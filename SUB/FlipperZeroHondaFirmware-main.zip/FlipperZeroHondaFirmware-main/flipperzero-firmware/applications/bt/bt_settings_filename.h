#pragma once

#define BT_SETTINGS_FILE_NAME ".bt.settings"
