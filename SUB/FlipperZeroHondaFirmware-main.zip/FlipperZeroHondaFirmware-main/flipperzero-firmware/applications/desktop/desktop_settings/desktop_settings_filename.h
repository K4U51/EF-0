#pragma once

#define DESKTOP_SETTINGS_FILE_NAME ".desktop.settings"
