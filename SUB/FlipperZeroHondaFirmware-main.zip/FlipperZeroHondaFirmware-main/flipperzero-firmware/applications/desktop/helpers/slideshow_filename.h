#pragma once

#define SLIDESHOW_FILE_NAME ".slideshow"
